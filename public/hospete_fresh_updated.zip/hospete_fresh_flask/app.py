import os
import sqlite3
import random
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash

# Safe password hashing helper with fallback
try:
    from werkzeug.security import generate_password_hash, check_password_hash
except ImportError:
    import hashlib
    def generate_password_hash(password):
        salt = 'hospete_fresh_salt_'
        return 'sha256$' + hashlib.sha256((salt + password).encode('utf-8')).hexdigest()
    def check_password_hash(p_hash, password):
        salt = 'hospete_fresh_salt_'
        if p_hash.startswith('sha256$'):
            return p_hash == ('sha256$' + hashlib.sha256((salt + password).encode('utf-8')).hexdigest())
        return p_hash == password

app = Flask(__name__)
app.secret_key = 'hospete_fresh_super_secret_key_2026'

DB_PATH = os.path.join(os.path.dirname(__file__), 'hospete_fresh.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def check_and_migrate_db():
    """Safe database schema migration logic preserving existing records"""
    conn = get_db()
    cursor = conn.cursor()
    
    # Ensure vendors table exists
    tables = [r[0] for r in cursor.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    if 'vendors' not in tables:
        cursor.execute('''
        CREATE TABLE vendors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            business_name TEXT NOT NULL,
            owner_name TEXT NOT NULL,
            phone TEXT UNIQUE NOT NULL,
            email TEXT,
            address TEXT NOT NULL,
            locality TEXT NOT NULL,
            service_area TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            business_type TEXT NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'pending',
            rejection_reason TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        ''')
    
    # Ensure products table columns exist
    prod_cols = [r[1] for r in cursor.execute("PRAGMA table_info(products)").fetchall()]
    if 'vendor_id' not in prod_cols:
        cursor.execute("ALTER TABLE products ADD COLUMN vendor_id INTEGER DEFAULT 1")
    if 'approval_status' not in prod_cols:
        cursor.execute("ALTER TABLE products ADD COLUMN approval_status TEXT DEFAULT 'approved'")
    if 'rejection_reason' not in prod_cols:
        cursor.execute("ALTER TABLE products ADD COLUMN rejection_reason TEXT")
    if 'sku' not in prod_cols:
        cursor.execute("ALTER TABLE products ADD COLUMN sku TEXT")

    # Ensure order_items columns exist
    item_cols = [r[1] for r in cursor.execute("PRAGMA table_info(order_items)").fetchall()]
    if 'vendor_id' not in item_cols:
        cursor.execute("ALTER TABLE order_items ADD COLUMN vendor_id INTEGER DEFAULT 1")
    if 'fulfillment_status' not in item_cols:
        cursor.execute("ALTER TABLE order_items ADD COLUMN fulfillment_status TEXT DEFAULT 'Pending'")

    conn.commit()
    conn.close()

# Run migration check once on startup
check_and_migrate_db()

# Vendor authorization decorator
def vendor_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'vendor_id' not in session:
            flash('Please log in to access the vendor portal.', 'warning')
            return redirect(url_for('vendor_login'))
        return f(*args, **kwargs)
    return decorated_function

@app.before_request
def make_session_permanent():
    if 'cart' not in session:
        session['cart'] = {}  # key: variant_id -> {product_id, name, pack_size, price, mrp, image_url, qty, vendor_id}
    if 'locality' not in session:
        session['locality'] = 'College Road'
        session['pincode'] = '583201'
        session['eta'] = 15

@app.context_processor
def inject_cart_and_vendor_data():
    cart = session.get('cart', {})
    total_qty = sum(item['qty'] for item in cart.values())
    total_amount = sum(item['price'] * item['qty'] for item in cart.values())
    total_mrp = sum(item['mrp'] * item['qty'] for item in cart.values())
    total_savings = total_mrp - total_amount
    
    conn = get_db()
    localities = conn.execute('SELECT * FROM localities').fetchall()
    
    current_vendor = None
    if 'vendor_id' in session:
        current_vendor = conn.execute('SELECT * FROM vendors WHERE id = ?', (session['vendor_id'],)).fetchone()
    conn.close()

    return {
        'cart_count': total_qty,
        'cart_total': total_amount,
        'cart_savings': max(0, total_savings),
        'cart_items': cart,
        'current_locality': session.get('locality', 'College Road'),
        'current_eta': session.get('eta', 15),
        'localities_list': localities,
        'current_vendor': current_vendor
    }

# ----------------- CUSTOMER ROUTES -----------------
# Only approved products appear in customer store!

@app.route('/')
def home():
    conn = get_db()
    shortcut = request.args.get('shortcut', 'all')
    search_query = request.args.get('q', '').strip()
    selected_cat = request.args.get('category', '').strip()

    categories = conn.execute('SELECT * FROM categories ORDER BY id ASC').fetchall()

    # Query for products: MUST be approved!
    sql = '''
        SELECT p.*, v.id as default_variant_id, v.pack_size, v.price, v.mrp, v.stock_qty,
               ROUND(((v.mrp - v.price) / v.mrp) * 100) as discount_pct
        FROM products p
        JOIN product_variants v ON p.id = v.product_id AND v.is_default = 1
        WHERE p.approval_status = 'approved'
    '''
    params = []
    conditions = []

    if search_query:
        conditions.append('(p.name LIKE ? OR p.brand LIKE ? OR p.description LIKE ?)')
        params.extend([f'%{search_query}%', f'%{search_query}%', f'%{search_query}%'])

    if selected_cat:
        conditions.append('p.category_slug = ?')
        params.append(selected_cat)

    if shortcut == 'offers':
        conditions.append('(p.is_deal = 1 OR (v.mrp > v.price))')
    elif shortcut == 'bestsellers':
        conditions.append('p.is_bestseller = 1')
    elif shortcut == 'fresh':
        conditions.append('p.is_fresh = 1')
    elif shortcut == 'bulk':
        conditions.append('p.is_bulk = 1')

    if conditions:
        sql += ' AND ' + ' AND '.join(conditions)

    sql += ' ORDER BY p.id ASC'
    products = conn.execute(sql, params).fetchall()

    # Today's deals
    deals = conn.execute('''
        SELECT p.*, v.id as default_variant_id, v.pack_size, v.price, v.mrp, v.stock_qty,
               ROUND(((v.mrp - v.price) / v.mrp) * 100) as discount_pct
        FROM products p
        JOIN product_variants v ON p.id = v.product_id AND v.is_default = 1
        WHERE p.is_deal = 1 AND p.approval_status = 'approved'
        LIMIT 6
    ''').fetchall()

    conn.close()
    return render_template('index.html',
                           categories=categories,
                           products=products,
                           deals=deals,
                           active_shortcut=shortcut,
                           search_query=search_query,
                           selected_category=selected_cat)

@app.route('/product/<int:product_id>')
def product_details(product_id):
    conn = get_db()
    product = conn.execute('SELECT * FROM products WHERE id = ?', (product_id,)).fetchone()
    if not product:
        conn.close()
        flash('Product not found', 'error')
        return redirect(url_for('home'))

    # If product is pending or rejected, verify whether current logged in vendor owns it
    if product['approval_status'] != 'approved':
        if 'vendor_id' not in session or session['vendor_id'] != product['vendor_id']:
            conn.close()
            flash('This product is currently under review by administrators.', 'warning')
            return redirect(url_for('home'))

    variants = conn.execute('''
        SELECT *, ROUND(((mrp - price) / mrp) * 100) as discount_pct
        FROM product_variants
        WHERE product_id = ?
        ORDER BY price ASC
    ''', (product_id,)).fetchall()

    category = conn.execute('SELECT * FROM categories WHERE slug = ?', (product['category_slug'],)).fetchone()

    # Similar products (must be approved)
    similar = conn.execute('''
        SELECT p.*, v.id as default_variant_id, v.pack_size, v.price, v.mrp, v.stock_qty,
               ROUND(((v.mrp - v.price) / v.mrp) * 100) as discount_pct
        FROM products p
        JOIN product_variants v ON p.id = v.product_id AND v.is_default = 1
        WHERE p.category_slug = ? AND p.id != ? AND p.approval_status = 'approved'
        LIMIT 4
    ''', (product['category_slug'], product_id)).fetchall()

    conn.close()
    return render_template('product_details.html',
                           product=product,
                           variants=variants,
                           category=category,
                           similar_products=similar)

@app.route('/categories')
def categories_page():
    conn = get_db()
    categories = conn.execute('SELECT * FROM categories ORDER BY id ASC').fetchall()
    
    cat_products = {}
    for cat in categories:
        prods = conn.execute('''
            SELECT p.*, v.id as default_variant_id, v.pack_size, v.price, v.mrp, v.stock_qty,
                   ROUND(((v.mrp - v.price) / v.mrp) * 100) as discount_pct
            FROM products p
            JOIN product_variants v ON p.id = v.product_id AND v.is_default = 1
            WHERE p.category_slug = ? AND p.approval_status = 'approved'
            LIMIT 4
        ''', (cat['slug'],)).fetchall()
        cat_products[cat['slug']] = prods
        
    conn.close()
    return render_template('categories.html', categories=categories, cat_products=cat_products)

@app.route('/search')
def search_page():
    query = request.args.get('q', '').strip()
    conn = get_db()
    products = []
    if query:
        products = conn.execute('''
            SELECT p.*, v.id as default_variant_id, v.pack_size, v.price, v.mrp, v.stock_qty,
                   ROUND(((v.mrp - v.price) / v.mrp) * 100) as discount_pct
            FROM products p
            JOIN product_variants v ON p.id = v.product_id AND v.is_default = 1
            WHERE (p.name LIKE ? OR p.brand LIKE ? OR p.category_slug LIKE ?)
              AND p.approval_status = 'approved'
        ''', (f'%{query}%', f'%{query}%', f'%{query}%')).fetchall()
    conn.close()
    return render_template('search.html', query=query, products=products)

@app.route('/set-location', methods=['POST'])
def set_location():
    locality = request.form.get('locality')
    conn = get_db()
    loc = conn.execute('SELECT * FROM localities WHERE name = ?', (locality,)).fetchone()
    conn.close()
    if loc:
        session['locality'] = loc['name']
        session['pincode'] = loc['pincode']
        session['eta'] = loc['eta_minutes']
    return redirect(request.referrer or url_for('home'))

# ----------------- CART & CHECKOUT -----------------

@app.route('/add-to-cart', methods=['POST'])
def add_to_cart():
    variant_id = request.form.get('variant_id', type=int)
    qty = request.form.get('qty', 1, type=int)

    conn = get_db()
    variant = conn.execute('''
        SELECT v.*, p.name as product_name, p.image_url, p.vendor_id, p.approval_status
        FROM product_variants v
        JOIN products p ON v.product_id = p.id
        WHERE v.id = ?
    ''', (variant_id,)).fetchone()
    conn.close()

    if not variant:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Product variant not found'}), 404
        return redirect(url_for('home'))

    # Must be approved and in stock
    if variant['approval_status'] != 'approved':
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'This product is currently pending admin approval.'}), 400
        flash('This product is not currently available for ordering.', 'warning')
        return redirect(request.referrer or url_for('home'))

    if variant['stock_qty'] <= 0:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'This item is currently out of stock.'}), 400
        flash(f"Sorry, {variant['product_name']} ({variant['pack_size']}) is currently out of stock.", 'warning')
        return redirect(request.referrer or url_for('home'))

    cart = session.get('cart', {})
    v_key = str(variant_id)
    if v_key in cart:
        cart[v_key]['qty'] += qty
    else:
        cart[v_key] = {
            'variant_id': variant['id'],
            'product_id': variant['product_id'],
            'vendor_id': variant['vendor_id'],
            'name': variant['product_name'],
            'pack_size': variant['pack_size'],
            'price': float(variant['price']),
            'mrp': float(variant['mrp']),
            'image_url': variant['image_url'],
            'qty': qty
        }

    session['cart'] = cart
    session.modified = True

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        total_qty = sum(item['qty'] for item in cart.values())
        total_amount = sum(item['price'] * item['qty'] for item in cart.values())
        return jsonify({
            'success': True,
            'cart_count': total_qty,
            'cart_total': total_amount,
            'item_qty': cart[v_key]['qty']
        })

    return redirect(request.referrer or url_for('cart_page'))

@app.route('/update-cart', methods=['POST'])
def update_cart():
    variant_id = str(request.form.get('variant_id'))
    qty = request.form.get('qty', type=int)

    cart = session.get('cart', {})
    if variant_id in cart:
        if qty <= 0:
            del cart[variant_id]
        else:
            cart[variant_id]['qty'] = qty
        session['cart'] = cart
        session.modified = True

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        total_qty = sum(item['qty'] for item in cart.values())
        total_amount = sum(item['price'] * item['qty'] for item in cart.values())
        return jsonify({
            'success': True,
            'cart_count': total_qty,
            'cart_total': total_amount,
            'item_qty': cart.get(variant_id, {}).get('qty', 0)
        })

    return redirect(url_for('cart_page'))

@app.route('/cart')
def cart_page():
    cart = session.get('cart', {})
    item_total = sum(item['price'] * item['qty'] for item in cart.values())
    mrp_total = sum(item['mrp'] * item['qty'] for item in cart.values())
    savings = mrp_total - item_total
    delivery_fee = 0 if item_total >= 199 or item_total == 0 else 25
    grand_total = item_total + delivery_fee

    return render_template('cart.html',
                           cart=cart,
                           item_total=item_total,
                           mrp_total=mrp_total,
                           savings=savings,
                           delivery_fee=delivery_fee,
                           grand_total=grand_total)

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    cart = session.get('cart', {})
    if not cart:
        flash('Your cart is empty', 'warning')
        return redirect(url_for('home'))

    item_total = sum(item['price'] * item['qty'] for item in cart.values())
    delivery_fee = 0 if item_total >= 199 else 25
    grand_total = item_total + delivery_fee

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        phone = request.form.get('phone', '').strip()
        address = request.form.get('address', '').strip()
        locality = request.form.get('locality', session.get('locality', 'Patel Nagar'))
        payment = request.form.get('payment_method', 'Cash on Delivery')

        order_num = f"HF-{random.randint(10000, 99999)}"

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO orders (order_number, customer_name, phone, delivery_address, locality, total_amount, payment_method, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'Placed')
        ''', (order_num, name, phone, address, locality, grand_total, payment))
        order_id = cursor.lastrowid

        for item in cart.values():
            cursor.execute('''
                INSERT INTO order_items (order_id, product_id, vendor_id, product_name, pack_size, unit_price, quantity, subtotal, fulfillment_status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending')
            ''', (order_id, item['product_id'], item.get('vendor_id', 1), item['name'], item['pack_size'], item['price'], item['qty'], item['price'] * item['qty']))

            # Decrement stock
            cursor.execute('''
                UPDATE product_variants
                SET stock_qty = MAX(0, stock_qty - ?)
                WHERE id = ?
            ''', (item['qty'], item['variant_id']))

        conn.commit()
        conn.close()

        # Clear cart
        session['cart'] = {}
        session.modified = True

        return redirect(url_for('order_success', order_id=order_id))

    return render_template('checkout.html',
                           cart=cart,
                           item_total=item_total,
                           delivery_fee=delivery_fee,
                           grand_total=grand_total)

@app.route('/order-success/<int:order_id>')
def order_success(order_id):
    conn = get_db()
    order = conn.execute('SELECT * FROM orders WHERE id = ?', (order_id,)).fetchone()
    items = conn.execute('SELECT * FROM order_items WHERE order_id = ?', (order_id,)).fetchall()
    conn.close()
    return render_template('order_success.html', order=order, items=items)

@app.route('/orders')
def orders_page():
    conn = get_db()
    orders = conn.execute('SELECT * FROM orders ORDER BY created_at DESC').fetchall()
    orders_with_items = []
    for ord_row in orders:
        items = conn.execute('SELECT * FROM order_items WHERE order_id = ?', (ord_row['id'],)).fetchall()
        orders_with_items.append({'order': ord_row, 'items': items})
    conn.close()
    return render_template('orders.html', orders=orders_with_items)

@app.route('/account')
def account_page():
    return render_template('account.html')

# ----------------- VENDOR ONBOARDING & AUTHENTICATION -----------------

@app.route('/vendor')
def vendor_entry():
    """Route entry: redirect to dashboard if authenticated, else login"""
    if 'vendor_id' in session:
        return redirect(url_for('vendor_dashboard'))
    return redirect(url_for('vendor_login'))

@app.route('/vendor/register', methods=['GET', 'POST'])
def vendor_register():
    if 'vendor_id' in session:
        return redirect(url_for('vendor_dashboard'))

    if request.method == 'POST':
        business_name = request.form.get('business_name', '').strip()
        owner_name = request.form.get('owner_name', '').strip()
        phone = request.form.get('phone', '').strip()
        email = request.form.get('email', '').strip()
        business_type = request.form.get('business_type', 'grocery')
        locality = request.form.get('locality', 'College Road')
        address = request.form.get('address', '').strip()
        service_area = request.form.get('service_area', 'All Hospete').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        description = request.form.get('description', '').strip()

        # Validation
        if not business_name or not owner_name or not phone or not address or not password:
            flash('Please fill in all required fields.', 'error')
            return redirect(url_for('vendor_register'))

        if len(phone) < 10 or not phone.isdigit():
            flash('Please enter a valid 10-digit mobile number.', 'error')
            return redirect(url_for('vendor_register'))

        if len(password) < 6:
            flash('Password must be at least 6 characters.', 'error')
            return redirect(url_for('vendor_register'))

        if password != confirm_password:
            flash('Passwords do not match. Please re-enter carefully.', 'error')
            return redirect(url_for('vendor_register'))

        conn = get_db()
        # Duplicate check
        existing = conn.execute('SELECT id FROM vendors WHERE phone = ? OR (email != "" AND email = ?)', (phone, email)).fetchone()
        if existing:
            conn.close()
            flash('A vendor account with this mobile number or email already exists. Please log in.', 'warning')
            return redirect(url_for('vendor_login'))

        # Secure password hashing
        pwd_hash = generate_password_hash(password)

        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO vendors (business_name, owner_name, phone, email, address, locality, service_area, password_hash, business_type, description, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        ''', (business_name, owner_name, phone, email, address, locality, service_area, pwd_hash, business_type, description))
        conn.commit()
        conn.close()

        flash('Registration submitted! Your vendor account is Pending Approval by Hospete Fresh administrators. (Note: SMS OTP verification will be integrated in a future release).', 'success')
        return redirect(url_for('vendor_login'))

    return render_template('vendor_register.html')

@app.route('/vendor/login', methods=['GET', 'POST'])
def vendor_login():
    if 'vendor_id' in session:
        return redirect(url_for('vendor_dashboard'))

    if request.method == 'POST':
        identifier = request.form.get('identifier', '').strip()
        password = request.form.get('password', '')

        if not identifier or not password:
            flash('Please enter your mobile number/email and password.', 'warning')
            return redirect(url_for('vendor_login'))

        conn = get_db()
        vendor = conn.execute('SELECT * FROM vendors WHERE phone = ? OR email = ?', (identifier, identifier)).fetchone()
        conn.close()

        if not vendor or not check_password_hash(vendor['password_hash'], password):
            flash('Invalid login credentials. Please check your mobile/email and password.', 'error')
            return redirect(url_for('vendor_login'))

        # Set session
        session['vendor_id'] = vendor['id']
        session['vendor_name'] = vendor['business_name']
        session['vendor_owner'] = vendor['owner_name']
        session['vendor_status'] = vendor['status']

        flash(f"Welcome back, {vendor['owner_name']} ({vendor['business_name']})!", 'success')
        return redirect(url_for('vendor_dashboard'))

    return render_template('vendor_login.html')

@app.route('/vendor/logout')
def vendor_logout():
    session.pop('vendor_id', None)
    session.pop('vendor_name', None)
    session.pop('vendor_owner', None)
    session.pop('vendor_status', None)
    flash('You have been logged out of the vendor portal.', 'info')
    return redirect(url_for('vendor_login'))

# ----------------- VENDOR DASHBOARD & PRODUCT MANAGEMENT -----------------

@app.route('/vendor/dashboard')
@vendor_required
def vendor_dashboard():
    vendor_id = session['vendor_id']
    conn = get_db()
    vendor = conn.execute('SELECT * FROM vendors WHERE id = ?', (vendor_id,)).fetchone()
    
    # Scoped metrics for this vendor
    total_products = conn.execute('SELECT COUNT(*) FROM products WHERE vendor_id = ?', (vendor_id,)).fetchone()[0]
    active_products = conn.execute('SELECT COUNT(*) FROM products WHERE vendor_id = ? AND approval_status = "approved"', (vendor_id,)).fetchone()[0]
    pending_products = conn.execute('SELECT COUNT(*) FROM products WHERE vendor_id = ? AND approval_status = "pending"', (vendor_id,)).fetchone()[0]
    
    total_variants = conn.execute('''
        SELECT COUNT(v.id)
        FROM product_variants v
        JOIN products p ON v.product_id = p.id
        WHERE p.vendor_id = ?
    ''', (vendor_id,)).fetchone()[0]

    out_of_stock = conn.execute('''
        SELECT COUNT(v.id)
        FROM product_variants v
        JOIN products p ON v.product_id = p.id
        WHERE p.vendor_id = ? AND v.stock_qty <= 0
    ''', (vendor_id,)).fetchone()[0]

    orders_count = conn.execute('''
        SELECT COUNT(DISTINCT oi.order_id)
        FROM order_items oi
        WHERE oi.vendor_id = ?
    ''', (vendor_id,)).fetchone()[0]

    total_sales = conn.execute('''
        SELECT COALESCE(SUM(oi.subtotal), 0)
        FROM order_items oi
        WHERE oi.vendor_id = ?
    ''', (vendor_id,)).fetchone()[0]

    # Recent order items for this vendor
    recent_orders = conn.execute('''
        SELECT oi.*, o.order_number, o.customer_name, o.locality, o.created_at
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.id
        WHERE oi.vendor_id = ?
        ORDER BY o.created_at DESC
        LIMIT 6
    ''', (vendor_id,)).fetchall()

    conn.close()

    metrics = {
        'total_products': total_products,
        'active_products': active_products,
        'pending_products': pending_products,
        'total_variants': total_variants,
        'out_of_stock': out_of_stock,
        'orders_count': orders_count,
        'total_sales': total_sales
    }

    return render_template('vendor_dashboard.html', vendor=vendor, metrics=metrics, recent_orders=recent_orders)

@app.route('/vendor/products')
@vendor_required
def vendor_products():
    vendor_id = session['vendor_id']
    conn = get_db()
    vendor = conn.execute('SELECT * FROM vendors WHERE id = ?', (vendor_id,)).fetchone()
    
    raw_products = conn.execute('SELECT * FROM products WHERE vendor_id = ? ORDER BY id DESC', (vendor_id,)).fetchall()
    
    products_with_variants = []
    for p in raw_products:
        variants = conn.execute('SELECT * FROM product_variants WHERE product_id = ? ORDER BY price ASC', (p['id'],)).fetchall()
        p_dict = dict(p)
        p_dict['variants'] = [dict(v) for v in variants]
        products_with_variants.append(p_dict)
        
    conn.close()
    return render_template('vendor_products.html', vendor=vendor, products=products_with_variants)

@app.route('/vendor/products/new', methods=['GET', 'POST'])
@vendor_required
def vendor_product_new():
    vendor_id = session['vendor_id']
    conn = get_db()
    vendor = conn.execute('SELECT * FROM vendors WHERE id = ?', (vendor_id,)).fetchone()

    # Suspended or rejected vendors cannot add products
    if vendor['status'] == 'suspended' or vendor['status'] == 'rejected':
        conn.close()
        flash('Your vendor account is not active for publishing products. Please contact admin.', 'error')
        return redirect(url_for('vendor_dashboard'))

    categories = conn.execute('SELECT * FROM categories ORDER BY id ASC').fetchall()

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        category_slug = request.form.get('category_slug', '').strip()
        brand = request.form.get('brand', '').strip()
        description = request.form.get('description', '').strip()
        image_url = request.form.get('image_url', '').strip() or '/static/images/cat_veggies.jpg'
        sku = request.form.get('sku', '').strip()

        pack_sizes = request.form.getlist('variant_pack_size[]')
        mrps = request.form.getlist('variant_mrp[]')
        prices = request.form.getlist('variant_price[]')
        stocks = request.form.getlist('variant_stock[]')

        if not name or not category_slug or not pack_sizes or not prices:
            conn.close()
            flash('Please provide product name, category, and at least one valid pack variant.', 'error')
            return redirect(url_for('vendor_product_new'))

        # Initial status is 'pending' for moderation
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO products (vendor_id, name, category_slug, brand, description, image_url, sku, approval_status)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
        ''', (vendor_id, name, category_slug, brand, description, image_url, sku))
        new_prod_id = cursor.lastrowid

        # Insert variants
        for i in range(len(pack_sizes)):
            p_size = pack_sizes[i].strip()
            if not p_size:
                continue
            mrp_val = float(mrps[i]) if i < len(mrps) and mrps[i] else float(prices[i])
            price_val = float(prices[i])
            stock_val = int(stocks[i]) if i < len(stocks) and stocks[i] else 0

            # Validate price
            if price_val <= 0:
                price_val = 1.0
            if price_val > mrp_val:
                mrp_val = price_val

            cursor.execute('''
                INSERT INTO product_variants (product_id, pack_size, price, mrp, stock_qty, is_default)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (new_prod_id, p_size, price_val, mrp_val, stock_val, 1 if i == 0 else 0))

        conn.commit()
        conn.close()
        flash('Product submitted successfully! It is now Pending Approval by administrators.', 'success')
        return redirect(url_for('vendor_products'))

    conn.close()
    return render_template('vendor_product_form.html', vendor=vendor, categories=categories, product=None, variants=None)

@app.route('/vendor/products/<int:product_id>/edit', methods=['GET', 'POST'])
@vendor_required
def vendor_product_edit(product_id):
    vendor_id = session['vendor_id']
    conn = get_db()
    vendor = conn.execute('SELECT * FROM vendors WHERE id = ?', (vendor_id,)).fetchone()
    product = conn.execute('SELECT * FROM products WHERE id = ? AND vendor_id = ?', (product_id, vendor_id)).fetchone()

    if not product:
        conn.close()
        flash('Product not found or access denied.', 'error')
        return redirect(url_for('vendor_products'))

    categories = conn.execute('SELECT * FROM categories ORDER BY id ASC').fetchall()
    variants = conn.execute('SELECT * FROM product_variants WHERE product_id = ? ORDER BY id ASC', (product_id,)).fetchall()

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        category_slug = request.form.get('category_slug', '').strip()
        brand = request.form.get('brand', '').strip()
        description = request.form.get('description', '').strip()
        image_url = request.form.get('image_url', '').strip() or product['image_url']
        sku = request.form.get('sku', '').strip()

        pack_sizes = request.form.getlist('variant_pack_size[]')
        mrps = request.form.getlist('variant_mrp[]')
        prices = request.form.getlist('variant_price[]')
        stocks = request.form.getlist('variant_stock[]')

        cursor = conn.cursor()
        # Reset approval status to 'pending' upon editing significant details
        cursor.execute('''
            UPDATE products
            SET name = ?, category_slug = ?, brand = ?, description = ?, image_url = ?, sku = ?, approval_status = 'pending', rejection_reason = NULL
            WHERE id = ? AND vendor_id = ?
        ''', (name, category_slug, brand, description, image_url, sku, product_id, vendor_id))

        # Rebuild variants safely
        cursor.execute('DELETE FROM product_variants WHERE product_id = ?', (product_id,))
        for i in range(len(pack_sizes)):
            p_size = pack_sizes[i].strip()
            if not p_size:
                continue
            mrp_val = float(mrps[i]) if i < len(mrps) and mrps[i] else float(prices[i])
            price_val = float(prices[i])
            stock_val = int(stocks[i]) if i < len(stocks) and stocks[i] else 0

            if price_val <= 0:
                price_val = 1.0
            if price_val > mrp_val:
                mrp_val = price_val

            cursor.execute('''
                INSERT INTO product_variants (product_id, pack_size, price, mrp, stock_qty, is_default)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (product_id, p_size, price_val, mrp_val, stock_val, 1 if i == 0 else 0))

        conn.commit()
        conn.close()
        flash('Product updated and resubmitted for admin approval.', 'success')
        return redirect(url_for('vendor_products'))

    conn.close()
    return render_template('vendor_product_form.html', vendor=vendor, categories=categories, product=product, variants=variants)

@app.route('/vendor/inventory')
@vendor_required
def vendor_portal():
    """Vendor Inventory & Stock Manager matching exact reference design, scoped to vendor"""
    vendor_id = session['vendor_id']
    conn = get_db()
    products = conn.execute('''
        SELECT p.*, v.id as variant_id, v.pack_size, v.price, v.mrp, v.stock_qty
        FROM products p
        JOIN product_variants v ON p.id = v.product_id
        WHERE p.vendor_id = ?
        ORDER BY p.name ASC, v.id ASC
    ''', (vendor_id,)).fetchall()
    conn.close()
    return render_template('vendor.html', products=products)

@app.route('/vendor/toggle-stock', methods=['POST'])
@vendor_required
def vendor_toggle_stock():
    vendor_id = session['vendor_id']
    variant_id = request.form.get('variant_id', type=int)
    action = request.form.get('action')
    quantity = request.form.get('quantity', 50, type=int)

    conn = get_db()
    # Enforce vendor ownership
    variant = conn.execute('''
        SELECT v.*, p.name as product_name, p.vendor_id
        FROM product_variants v
        JOIN products p ON v.product_id = p.id
        WHERE v.id = ? AND p.vendor_id = ?
    ''', (variant_id, vendor_id)).fetchone()

    if not variant:
        conn.close()
        flash('Product variant not found or access denied.', 'error')
        return redirect(url_for('vendor_portal'))

    if action == 'set_out_of_stock':
        conn.execute('UPDATE product_variants SET stock_qty = 0 WHERE id = ?', (variant_id,))
        conn.commit()
        conn.close()
        flash(f"{variant['product_name']} ({variant['pack_size']}) marked Out of Stock.", 'warning')
    else:
        conn.execute('UPDATE product_variants SET stock_qty = ? WHERE id = ?', (quantity, variant_id))
        conn.commit()
        conn.close()
        flash(f"{variant['product_name']} ({variant['pack_size']}) restocked with {quantity} units.", 'success')

    return redirect(url_for('vendor_portal'))

@app.route('/vendor/orders')
@vendor_required
def vendor_orders():
    """Vendor view of customer order items assigned to this vendor only"""
    vendor_id = session['vendor_id']
    conn = get_db()
    vendor = conn.execute('SELECT * FROM vendors WHERE id = ?', (vendor_id,)).fetchone()
    
    orders = conn.execute('''
        SELECT oi.*, o.order_number, o.customer_name, o.phone, o.delivery_address, o.locality, o.payment_method, o.created_at
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.id
        WHERE oi.vendor_id = ?
        ORDER BY o.created_at DESC
    ''', (vendor_id,)).fetchall()
    
    conn.close()
    return render_template('vendor_orders.html', vendor=vendor, orders=orders)

@app.route('/vendor/orders/<int:item_id>/status', methods=['POST'])
@vendor_required
def vendor_order_status_update(item_id):
    vendor_id = session['vendor_id']
    new_status = request.form.get('status')

    conn = get_db()
    item = conn.execute('SELECT * FROM order_items WHERE id = ? AND vendor_id = ?', (item_id, vendor_id)).fetchone()
    if not item:
        conn.close()
        flash('Order item not found or access denied.', 'error')
        return redirect(url_for('vendor_orders'))

    conn.execute('UPDATE order_items SET fulfillment_status = ? WHERE id = ?', (new_status, item_id))
    conn.commit()
    conn.close()
    flash(f"Order item #{item_id} marked as '{new_status}'.", 'success')
    return redirect(url_for('vendor_orders'))

@app.route('/vendor/profile', methods=['GET', 'POST'])
@vendor_required
def vendor_profile():
    vendor_id = session['vendor_id']
    conn = get_db()

    if request.method == 'POST':
        business_name = request.form.get('business_name', '').strip()
        owner_name = request.form.get('owner_name', '').strip()
        email = request.form.get('email', '').strip()
        business_type = request.form.get('business_type', 'grocery')
        locality = request.form.get('locality', 'College Road')
        address = request.form.get('address', '').strip()
        service_area = request.form.get('service_area', '').strip()
        description = request.form.get('description', '').strip()

        conn.execute('''
            UPDATE vendors
            SET business_name = ?, owner_name = ?, email = ?, business_type = ?, locality = ?, address = ?, service_area = ?, description = ?
            WHERE id = ?
        ''', (business_name, owner_name, email, business_type, locality, address, service_area, description, vendor_id))
        conn.commit()
        session['vendor_name'] = business_name
        session['vendor_owner'] = owner_name
        flash('Store profile updated successfully.', 'success')

    vendor = conn.execute('SELECT * FROM vendors WHERE id = ?', (vendor_id,)).fetchone()
    conn.close()
    return render_template('vendor_profile.html', vendor=vendor)

# ----------------- ADMIN CONSOLE & VENDOR MODERATION -----------------

@app.route('/admin')
def admin_portal():
    conn = get_db()
    total_revenue = conn.execute('SELECT COALESCE(SUM(total_amount), 0) FROM orders').fetchone()[0]
    total_orders = conn.execute('SELECT COUNT(*) FROM orders').fetchone()[0]
    total_products = conn.execute('SELECT COUNT(*) FROM products WHERE approval_status = "approved"').fetchone()[0]
    recent_orders = conn.execute('SELECT * FROM orders ORDER BY created_at DESC LIMIT 10').fetchall()

    vendors = conn.execute('SELECT * FROM vendors ORDER BY id DESC').fetchall()
    
    raw_pending = conn.execute('''
        SELECT p.*, v.business_name as vendor_name
        FROM products p
        JOIN vendors v ON p.vendor_id = v.id
        WHERE p.approval_status = 'pending'
        ORDER BY p.id DESC
    ''').fetchall()

    pending_products = []
    for p in raw_pending:
        variants = conn.execute('SELECT * FROM product_variants WHERE product_id = ?', (p['id'],)).fetchall()
        p_dict = dict(p)
        p_dict['variants'] = [dict(v) for v in variants]
        pending_products.append(p_dict)

    conn.close()
    return render_template('admin.html',
                           revenue=total_revenue,
                           orders_count=total_orders,
                           products_count=total_products,
                           recent_orders=recent_orders,
                           vendors=vendors,
                           pending_products=pending_products)

@app.route('/admin/vendors/<int:vendor_id>/approve', methods=['POST'])
def admin_vendor_approve(vendor_id):
    conn = get_db()
    conn.execute('UPDATE vendors SET status = "approved", rejection_reason = NULL WHERE id = ?', (vendor_id,))
    conn.commit()
    conn.close()
    flash('Vendor application approved! They can now publish live catalog items.', 'success')
    return redirect(url_for('admin_portal'))

@app.route('/admin/vendors/<int:vendor_id>/reject', methods=['POST'])
def admin_vendor_reject(vendor_id):
    reason = request.form.get('reason', 'Application did not meet marketplace guidelines.').strip()
    conn = get_db()
    conn.execute('UPDATE vendors SET status = "rejected", rejection_reason = ? WHERE id = ?', (reason, vendor_id))
    conn.commit()
    conn.close()
    flash('Vendor application marked as rejected.', 'warning')
    return redirect(url_for('admin_portal'))

@app.route('/admin/vendors/<int:vendor_id>/toggle-status', methods=['POST'])
def admin_vendor_toggle(vendor_id):
    new_status = request.form.get('status', 'suspended')
    conn = get_db()
    conn.execute('UPDATE vendors SET status = ? WHERE id = ?', (new_status, vendor_id))
    conn.commit()
    conn.close()
    flash(f"Vendor account status changed to '{new_status}'.", 'info')
    return redirect(url_for('admin_portal'))

@app.route('/admin/products/<int:product_id>/approve', methods=['POST'])
def admin_product_approve(product_id):
    conn = get_db()
    conn.execute('UPDATE products SET approval_status = "approved", rejection_reason = NULL WHERE id = ?', (product_id,))
    conn.commit()
    conn.close()
    flash('Product approved! It is now live in the customer storefront.', 'success')
    return redirect(url_for('admin_portal'))

@app.route('/admin/products/<int:product_id>/reject', methods=['POST'])
def admin_product_reject(product_id):
    reason = request.form.get('reason', 'Pricing or details need revision.').strip()
    conn = get_db()
    conn.execute('UPDATE products SET approval_status = "rejected", rejection_reason = ? WHERE id = ?', (reason, product_id))
    conn.commit()
    conn.close()
    flash('Product rejected and sent back to vendor for edits.', 'warning')
    return redirect(url_for('admin_portal'))

# ----------------- DELIVERY FLEET -----------------

@app.route('/delivery')
def delivery_dashboard():
    conn = get_db()
    orders = conn.execute('SELECT * FROM orders ORDER BY id DESC').fetchall()
    orders_data = []
    for ord_row in orders:
        items = conn.execute('SELECT * FROM order_items WHERE order_id = ?', (ord_row['id'],)).fetchall()
        orders_data.append({'order': ord_row, 'items': items})
    conn.close()
    return render_template('delivery.html', orders=orders_data)

@app.route('/delivery/update-status', methods=['POST'])
def delivery_update_status():
    order_id = request.form.get('order_id', type=int)
    new_status = request.form.get('status')
    conn = get_db()
    conn.execute('UPDATE orders SET status = ? WHERE id = ?', (new_status, order_id))
    conn.commit()
    conn.close()
    flash(f'Order #{order_id} marked as {new_status}', 'info')
    return redirect(url_for('delivery_dashboard'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
